__author__ = 'thauane'

print("Conversor de metros para centímetros hehehe")

m = float(input("por favor, cite quantos metros você deseja converter: ").replace(',','.'))
cm = (m*100)

print("Sua metragem convertida foi: ",cm)

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

notas = {4.0, 6.0, 10.0, 8.0}

media = sum(notas)/4

print('A média aritmética das notas é: ',media)